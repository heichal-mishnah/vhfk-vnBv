// app.js — לוגיקת האתר. משתמש ב-localStorage כתשתית זמנית במקום נדרים פלוס אמיתי.

const DB = {
  get(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch (e) {
      return fallback;
    }
  },
  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },
};

const KEYS = {
  registrants: "mishnayot_registrants",
  unitsTaken: "mishnayot_unitsTaken", // { [unitId]: registrantId }
  contTaken: "mishnayot_contTaken", // { [seder|masechet|perek]: registrantId }
  contProgress: "mishnayot_contProgress", // { [registrantId]: {seder,masechet,perek,confirmedCount} }
  confirmed: "mishnayot_confirmed", // { [registrantId]: ["masechet-perek", ...] }
  announcement: "mishnayot_announcement",
  dismissed: "mishnayot_dismissed_announcement",
  questionBank: "mishnayot_questionBank",
  notices: "mishnayot_notices",
  taharotConfig: "mishnayot_taharotConfig",
  taharotConfirmed: "mishnayot_taharotConfirmed", // { [registrantId]: ["masechet-perek-mishnah", ...] }
  taharotMap: "mishnayot_taharotMishnayotMap", // { "masechet-perek": count }
};

const TYPE_LABELS = { "משנה": "משנה", "רעב": 'רע"ב', "רעב-מורחב": 'רע"ב מורחב' };
const TYPE_COUNTS = { "משנה": 3, "רעב": 3, "רעב-מורחב": 10 };

let currentRegistrant = null; // registrant object created during this session's registration flow

// ---------- Navigation ----------
function goTo(view) {
  document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
  const target = document.getElementById(`view-${view}`);
  if (target) target.classList.add("active");
  document.querySelectorAll(".topbar nav button").forEach((b) =>
    b.classList.toggle("active", b.dataset.nav === view)
  );
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
}

document.querySelectorAll("[data-nav]").forEach((el) => {
  el.addEventListener("click", () => goTo(el.dataset.nav));
});

// ---------- Registration ----------
document.getElementById("reg-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const id = f.get("id").trim();
  const registrants = DB.get(KEYS.registrants, []);

  let reg = registrants.find((r) => r.id === id);
  if (!reg) {
    reg = {
      id,
      first: f.get("first"),
      last: f.get("last"),
      phone: f.get("phone"),
      status: f.get("status"),
      city: f.get("city"),
      unitId: null,
      unitLabel: null,
    };
    registrants.push(reg);
    DB.set(KEYS.registrants, registrants);
  }
  currentRegistrant = reg;

  const msg = document.getElementById("reg-msg");
  msg.innerHTML = `<div class="msg ok">שלום ${reg.first}, ההרשמה נקלטה. בחרו כעת יחידת לימוד למטה.</div>`;
  document.getElementById("unit-picker-card").style.display = "block";
  renderUnitGrid();
});

document.getElementById("unit-size").addEventListener("change", renderUnitGrid);

function renderUnitGrid() {
  const size = Number(document.getElementById("unit-size").value);
  const units = computeUnits(size);
  const taken = DB.get(KEYS.unitsTaken, {});
  const grid = document.getElementById("unit-grid");
  grid.innerHTML = "";

  units.forEach((u) => {
    const isTaken = !!taken[u.id];
    const isMine = currentRegistrant && taken[u.id] === currentRegistrant.id;
    const tile = document.createElement("div");
    tile.className = "unit-tile" + (isTaken && !isMine ? " taken" : "");
    tile.innerHTML = `
      <div class="seder-tag">סדר ${u.seder}</div>
      <div>${u.label}</div>
      <button ${isTaken ? "disabled" : ""}>${
      isMine ? "היחידה שלכם ✓" : isTaken ? "תפוסה" : "בחרו יחידה זו"
    }</button>
    `;
    tile.querySelector("button").addEventListener("click", () => {
      if (!currentRegistrant) return;
      const takenNow = DB.get(KEYS.unitsTaken, {});
      if (takenNow[u.id]) return;
      takenNow[u.id] = currentRegistrant.id;
      DB.set(KEYS.unitsTaken, takenNow);

      const registrants = DB.get(KEYS.registrants, []);
      const r = registrants.find((r) => r.id === currentRegistrant.id);
      r.unitId = u.id;
      r.unitLabel = u.label;
      DB.set(KEYS.registrants, registrants);
      currentRegistrant = r;

      renderUnitGrid();
      renderAdminRegistrants();
      renderStatusSummary();
    });
    grid.appendChild(tile);
  });
}

// ---------- Continuous track ----------
function renderStartPoints() {
  const points = allStartingPoints();
  const taken = DB.get(KEYS.contTaken, {});
  const wrap = document.getElementById("start-points");
  wrap.innerHTML = "";

  points.forEach((p) => {
    const key = `${p.seder}|${p.masechet}|${p.perek}`;
    const isTaken = !!taken[key];
    const tile = document.createElement("div");
    tile.className = "unit-tile" + (isTaken ? " taken" : "");
    tile.innerHTML = `
      <div class="seder-tag">סדר ${p.seder}</div>
      <div>${p.masechet} פרק ${p.perek}</div>
      <button ${isTaken ? "disabled" : ""}>${isTaken ? "תפוס" : "התחילו כאן"}</button>
    `;
    tile.querySelector("button").addEventListener("click", () => {
      if (!currentRegistrant) {
        alert("יש להירשם קודם דרך חלוקת שס משניות (טופס ההרשמה).");
        goTo("units");
        return;
      }
      const takenNow = DB.get(KEYS.contTaken, {});
      if (takenNow[key]) return;
      takenNow[key] = currentRegistrant.id;
      DB.set(KEYS.contTaken, takenNow);

      const progress = DB.get(KEYS.contProgress, {});
      progress[currentRegistrant.id] = {
        seder: p.seder,
        masechet: p.masechet,
        perek: p.perek,
        confirmedCount: 0,
      };
      DB.set(KEYS.contProgress, progress);
      renderStartPoints();
      renderStatusSummary();
      alert("נקבעה נקודת ההתחלה שלכם. תוכלו לעקוב ולאשר לימוד שבועי באזור האישי.");
      goTo("personal");
    });
    wrap.appendChild(tile);
  });
}

// add a link from units view into the continuous track
(function addContinuousLink() {
  const card = document.getElementById("unit-picker-card");
  const p = document.createElement("p");
  p.style.marginTop = "14px";
  p.innerHTML = `מעוניינים במסלול הרציף במקום? <button class="back-link" data-nav="continuous">מעבר למסלול הרציף ←</button>`;
  card.appendChild(p);
  p.querySelector("button").addEventListener("click", () => {
    renderStartPoints();
  });
})();

// ---------- Personal area ----------
document.getElementById("personal-go").addEventListener("click", () => {
  const id = document.getElementById("personal-id").value.trim();
  const area = document.getElementById("personal-area");
  const registrants = DB.get(KEYS.registrants, []);
  const reg = registrants.find((r) => r.id === id);

  if (!reg) {
    area.innerHTML = `<div class="msg err">לא נמצאה הרשמה עם מספר זהות זה.</div>`;
    return;
  }
  currentRegistrant = reg;
  const progress = DB.get(KEYS.contProgress, {})[id];

  if (progress) {
    renderContinuousPersonal(area, reg, progress);
  } else if (reg.unitId) {
    renderUnitPersonal(area, reg);
  } else {
    area.innerHTML = `<div class="msg err">עדיין לא נבחרה יחידת לימוד. <button class="back-link" data-nav="units">מעבר לבחירת יחידה</button></div>`;
  }
});

function renderUnitPersonal(area, reg) {
  const units8 = computeUnits(8);
  const units4 = computeUnits(4);
  const unit = [...units8, ...units4].find((u) => u.id === reg.unitId);
  if (!unit) {
    area.innerHTML = `<div class="msg err">שגיאה באיתור היחידה.</div>`;
    return;
  }
  const confirmed = DB.get(KEYS.confirmed, {})[reg.id] || [];

  area.innerHTML = `
    <div class="card">
      <h3>שלום ${reg.first} ${reg.last} — היחידה שלכם: ${unit.label}</h3>
      <ul class="perek-list" id="perek-list"></ul>
    </div>
  `;
  const list = document.getElementById("perek-list");
  unit.perakim.forEach((p) => {
    const key = `${p.masechet}-${p.perek}`;
    const done = confirmed.includes(key);
    const li = document.createElement("li");
    li.className = done ? "done" : "";
    li.innerHTML = `<span>${p.masechet} פרק ${p.perek}</span><button ${
      done ? "disabled" : ""
    }>${done ? "אושר ✓" : "אשר לימוד"}</button>`;
    li.querySelector("button").addEventListener("click", () => {
      const all = DB.get(KEYS.confirmed, {});
      all[reg.id] = all[reg.id] || [];
      if (!all[reg.id].includes(key)) all[reg.id].push(key);
      DB.set(KEYS.confirmed, all);
      renderUnitPersonal(area, reg);
    });
    list.appendChild(li);
  });
}

function renderContinuousPersonal(area, reg, progress) {
  area.innerHTML = `
    <div class="card">
      <h3>שלום ${reg.first} ${reg.last} — מסלול רציף</h3>
      <p>הפרק הנוכחי שלכם: <strong>${progress.masechet} פרק ${progress.perek}</strong> (סדר ${progress.seder})</p>
      <p style="color:var(--ink-soft)">פרקים שאושרו עד כה: ${progress.confirmedCount}</p>
      <button class="btn" id="confirm-cont">אישור לימוד השבוע והמשך לפרק הבא</button>
    </div>
  `;
  document.getElementById("confirm-cont").addEventListener("click", () => {
    const next = nextPerek(progress.seder, progress.masechet, progress.perek);
    const all = DB.get(KEYS.contProgress, {});
    all[reg.id] = {
      seder: next.seder,
      masechet: next.masechet,
      perek: next.perek,
      confirmedCount: (all[reg.id].confirmedCount || 0) + 1,
    };
    DB.set(KEYS.contProgress, all);
    renderContinuousPersonal(area, reg, all[reg.id]);
  });
}

// ---------- Question bank upload (admin) ----------
function updateBankCount() {
  const bank = DB.get(KEYS.questionBank, []);
  document.getElementById("bank-count").textContent = bank.length;
}

document.getElementById("bank-upload").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const msg = document.getElementById("bank-msg");
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const wb = XLSX.read(ev.target.result, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

      const parsed = rows
        .map((r) => {
          const options = [r["תשובה1"], r["תשובה2"], r["תשובה3"], r["תשובה4"]].map((o) =>
            String(o).trim()
          );
          const correctIndex = Number(r["נכונה"]) - 1;
          return {
            masechet: String(r["מסכת"] || "").trim(),
            perek: Number(r["פרק"]) || null,
            type: String(r["סוג"] || "").trim(),
            question: String(r["שאלה"] || "").trim(),
            options,
            correctIndex,
          };
        })
        .filter((q) => q.masechet && q.question && q.options.every((o) => o));

      if (!parsed.length) {
        msg.innerHTML = `<div class="msg err">לא נמצאו שורות תקינות בקובץ. בדקו את שמות העמודות.</div>`;
        return;
      }

      const existing = DB.get(KEYS.questionBank, []);
      DB.set(KEYS.questionBank, existing.concat(parsed));
      msg.innerHTML = `<div class="msg ok">נטענו ${parsed.length} שאלות ונוספו לבנק.</div>`;
      updateBankCount();
      renderExamMasechetList();
    } catch (err) {
      msg.innerHTML = `<div class="msg err">שגיאה בקריאת הקובץ: ${err.message}</div>`;
    }
  };
  reader.readAsArrayBuffer(file);
});

// ---------- Mishnayot-per-perek reference table (admin upload) ----------
function updateMishnayotMapCount() {
  const map = DB.get(KEYS.taharotMap, {});
  document.getElementById("mishnayot-map-count").textContent = Object.keys(map).length;
}

document.getElementById("mishnayot-map-upload").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const msg = document.getElementById("mishnayot-map-msg");
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const wb = XLSX.read(ev.target.result, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

      const map = DB.get(KEYS.taharotMap, {});
      let added = 0;
      rows.forEach((r) => {
        const masechet = String(r["מסכת"] || "").trim();
        const perek = Number(r["פרק"]);
        const count = Number(r["מספר משניות"]);
        if (masechet && perek && count) {
          map[`${masechet}-${perek}`] = count;
          added++;
        }
      });
      if (!added) {
        msg.innerHTML = `<div class="msg err">לא נמצאו שורות תקינות. בדקו את שמות העמודות: מסכת, פרק, מספר משניות.</div>`;
        return;
      }
      DB.set(KEYS.taharotMap, map);
      msg.innerHTML = `<div class="msg ok">נטענו נתונים ל-${added} פרקים.</div>`;
      updateMishnayotMapCount();
    } catch (err) {
      msg.innerHTML = `<div class="msg err">שגיאה בקריאת הקובץ: ${err.message}</div>`;
    }
  };
  reader.readAsArrayBuffer(file);
});

// ---------- Seder Taharot daily schedule (mishnah-level) ----------
function getTaharotMishnaFlat() {
  const seder = SHAS.find((s) => s.seder === "טהרות");
  const perakim = flattenSeder(seder);
  const map = DB.get(KEYS.taharotMap, {});
  const flat = [];
  perakim.forEach((p) => {
    const count = map[`${p.masechet}-${p.perek}`];
    if (!count) return; // מדלגים על פרקים שאין להם עדיין נתון במפה
    for (let m = 1; m <= count; m++) {
      flat.push({ masechet: p.masechet, perek: p.perek, mishnah: m });
    }
  });
  return flat;
}

function getTaharotConfig() {
  return DB.get(KEYS.taharotConfig, {
    startDate: new Date().toISOString().slice(0, 10),
    pace: 1,
    examCadence: 7,
  });
}

function taharotDateForStep(config, step) {
  const start = new Date(config.startDate + "T00:00:00");
  return new Date(start.getTime() + step * config.pace * 86400000);
}

// admin: load/save config
function loadTaharotConfigForm() {
  const cfg = getTaharotConfig();
  document.getElementById("taharot-start").value = cfg.startDate;
  document.getElementById("taharot-pace").value = cfg.pace;
  document.getElementById("taharot-exam-cadence").value = cfg.examCadence;
}

document.getElementById("taharot-save-config").addEventListener("click", () => {
  const startDate =
    document.getElementById("taharot-start").value || new Date().toISOString().slice(0, 10);
  const pace = Number(document.getElementById("taharot-pace").value) || 1;
  const examCadence = Number(document.getElementById("taharot-exam-cadence").value) || 7;
  DB.set(KEYS.taharotConfig, { startDate, pace, examCadence });
  alert("ההגדרות נשמרו.");
});

document.getElementById("taharot-go").addEventListener("click", () => {
  const id = document.getElementById("taharot-id").value.trim();
  const registrants = DB.get(KEYS.registrants, []);
  const reg = registrants.find((r) => r.id === id);
  const area = document.getElementById("taharot-area");

  if (!reg) {
    area.innerHTML = `<div class="msg err">לא נמצאה הרשמה עם מספר זהות זה. יש להירשם קודם ב"חלוקת שס משניות" (ההרשמה משותפת לכל המסלולים). <button class="back-link" data-nav="units">מעבר להרשמה</button></div>`;
    area.querySelector("[data-nav]").addEventListener("click", () => goTo("units"));
    return;
  }

  const flat = getTaharotMishnaFlat();
  if (!flat.length) {
    area.innerHTML = `<div class="msg err">טרם הועלתה טבלת "משניות לכל פרק" בלוח הניהול, כך שהלוח היומי עדיין לא יכול להיבנות.</div>`;
    return;
  }

  const config = getTaharotConfig();
  const today = new Date();
  const start = new Date(config.startDate + "T00:00:00");
  const daysSinceStart = Math.floor((today - start) / 86400000);
  const todayStepAbs = Math.floor(daysSinceStart / Math.max(1, config.pace));

  const confirmedAll = DB.get(KEYS.taharotConfirmed, {});
  const confirmed = confirmedAll[reg.id] || [];

  const RANGE_BACK = 4;
  const RANGE_FWD = 2;
  let rows = "";
  for (let s = todayStepAbs - RANGE_BACK; s <= todayStepAbs + RANGE_FWD; s++) {
    const idx = ((s % flat.length) + flat.length) % flat.length;
    const p = flat[idx];
    const key = `${p.masechet}-${p.perek}-${p.mishnah}`;
    const date = taharotDateForStep(config, s);
    const isToday = s === todayStepAbs;
    const isPastOrToday = s <= todayStepAbs;
    const done = confirmed.includes(key);
    rows += `<li class="${done ? "done" : ""}" style="${isToday ? "border-color:var(--wine)" : ""}">
      <span>${date.toLocaleDateString("he-IL")} — ${p.masechet} פרק ${p.perek} משנה ${p.mishnah}${
      isToday ? " (היום)" : ""
    }</span>
      ${
        isPastOrToday
          ? `<button ${done ? "disabled" : ""} data-key="${key}">${done ? "אושר ✓" : "אשר לימוד"}</button>`
          : `<span style="color:var(--ink-soft); font-size:.8rem">עתידי</span>`
      }
    </li>`;
  }

  const todayIdx = ((todayStepAbs % flat.length) + flat.length) % flat.length;
  const todayMishnah = flat[todayIdx];

  // תדירות מבחן: לא יותר מפעם ב-examCadence ימים
  const cadence = Math.max(1, config.examCadence);
  const daysIntoWindow = ((daysSinceStart % cadence) + cadence) % cadence;
  const isExamDay = daysIntoWindow === 0;
  const daysUntilExam = cadence - daysIntoWindow;

  const examBlock = isExamDay
    ? `<button class="btn secondary" id="taharot-exam-btn">מבחן שבועי — ${todayMishnah.masechet} פרק ${todayMishnah.perek}</button>`
    : `<p style="color:var(--ink-soft); font-size:.9rem">המבחן הבא ייפתח בעוד ${daysUntilExam} ${
        daysUntilExam === 1 ? "יום" : "ימים"
      }.</p>`;

  area.innerHTML = `
    <p>שלום ${reg.first} ${reg.last}. היום לומדים: <strong>${todayMishnah.masechet} פרק ${todayMishnah.perek} משנה ${todayMishnah.mishnah}</strong></p>
    ${examBlock}
    <ul class="perek-list" id="taharot-list" style="grid-template-columns:1fr; margin-top:14px">${rows}</ul>
  `;

  area.querySelectorAll("#taharot-list button[data-key]").forEach((b) =>
    b.addEventListener("click", () => {
      const all = DB.get(KEYS.taharotConfirmed, {});
      all[reg.id] = all[reg.id] || [];
      if (!all[reg.id].includes(b.dataset.key)) all[reg.id].push(b.dataset.key);
      DB.set(KEYS.taharotConfirmed, all);
      document.getElementById("taharot-go").click();
    })
  );

  const examBtn = document.getElementById("taharot-exam-btn");
  if (examBtn) {
    examBtn.addEventListener("click", () => {
      goTo("exams");
      renderExamMasechetList();
      renderExamPerekList(todayMishnah.masechet);
    });
  }
});

// ---------- Exams ----------
const PRIORITY_MASECHTOT = ["ראש השנה", "יומא", "סוכה"];

function bankByMasechet() {
  const bank = DB.get(KEYS.questionBank, []);
  const set = new Set(PRIORITY_MASECHTOT);
  bank.forEach((q) => set.add(q.masechet));
  return Array.from(set);
}

function renderExamMasechetList() {
  const bank = DB.get(KEYS.questionBank, []);
  const list = document.getElementById("exam-masechet-list");
  list.innerHTML = "";
  bankByMasechet().forEach((masechet) => {
    const count = bank.filter((q) => q.masechet === masechet).length;
    const tile = document.createElement("div");
    tile.className = "unit-tile" + (count ? "" : " taken");
    tile.innerHTML = `
      <div class="seder-tag">מסכת</div>
      <div>${masechet}</div>
      <button ${count ? "" : "disabled"}>${
      count ? `${count} שאלות מוכנות` : "אין עדיין שאלות"
    }</button>
    `;
    tile.querySelector("button").addEventListener("click", () => {
      if (!count) return;
      renderExamPerekList(masechet);
    });
    list.appendChild(tile);
  });
}

function renderExamPerekList(masechet) {
  const bank = DB.get(KEYS.questionBank, []);
  document.getElementById("exam-perek-card").style.display = "block";
  document.getElementById("exam-perek-title").textContent = `${masechet} — בחרו פרק`;
  const perakim = Array.from(
    new Set(bank.filter((q) => q.masechet === masechet).map((q) => q.perek))
  ).sort((a, b) => a - b);

  const list = document.getElementById("exam-perek-list");
  list.innerHTML = "";
  if (!perakim.length) {
    list.innerHTML = `<div class="msg err">טרם הועלו שאלות למסכת ${masechet}. יש להעלות בנק שאלות בלוח הניהול.</div>`;
    document.getElementById("exam-area").innerHTML = "";
    return;
  }
  perakim.forEach((perek) => {
    const tile = document.createElement("div");
    tile.className = "unit-tile";
    tile.innerHTML = `<div class="seder-tag">פרק</div><div>${perek}</div>`;
    const btnRow = document.createElement("div");
    btnRow.style.display = "flex";
    btnRow.style.gap = "6px";
    btnRow.style.marginTop = "8px";
    ["משנה", "רעב", "רעב-מורחב"].forEach((type) => {
      const n = bank.filter(
        (q) => q.masechet === masechet && q.perek === perek && q.type === type
      ).length;
      const b = document.createElement("button");
      b.textContent = `${TYPE_LABELS[type]}${n ? ` (${n})` : ""}`;
      b.style.flex = "1";
      b.disabled = !n;
      b.addEventListener("click", () => renderFixedExam(masechet, perek, type));
      btnRow.appendChild(b);
    });
    tile.appendChild(btnRow);
    list.appendChild(tile);
  });
  document.getElementById("exam-area").innerHTML = "";
}

function renderFixedExam(masechet, perek, type) {
  const bank = DB.get(KEYS.questionBank, []);
  // הרשימה הקבועה: כל השאלות שהועלו לצירוף הזה, לפי סדר ההעלאה — לא אקראי
  const questions = bank.filter(
    (q) => q.masechet === masechet && q.perek === perek && q.type === type
  );

  const area = document.getElementById("exam-area");
  const today = new Date().toLocaleDateString("he-IL");

  let html = `
    <div class="exam-header">
      <div><span class="k">מסלול</span>מערכת מבחנים</div>
      <div><span class="k">סוג מבחן</span>${TYPE_LABELS[type]}</div>
      <div><span class="k">תאריך</span>${today}</div>
      <div><span class="k">מסכת ופרק</span>${masechet} פרק ${perek}</div>
    </div>
  `;
  questions.forEach((q, i) => {
    html += `
      <div class="question-box" data-correct="${q.correctIndex}">
        <p class="q-text">שאלה ${i + 1} — ${q.question}</p>
        ${q.options
          .map(
            (o, oi) =>
              `<label class="option"><input type="radio" name="q${i}" value="${oi}" /> ${o}</label>`
          )
          .join("")}
      </div>
    `;
  });
  html += `<button class="btn" id="submit-exam">הגשת מבחן</button><div id="exam-result"></div>`;
  area.innerHTML = html;

  document.getElementById("submit-exam").addEventListener("click", () => {
    const boxes = area.querySelectorAll(".question-box");
    let correct = 0;
    boxes.forEach((box, i) => {
      const chosen = box.querySelector(`input[name="q${i}"]:checked`);
      if (chosen && Number(chosen.value) === Number(box.dataset.correct)) correct++;
    });
    document.getElementById(
      "exam-result"
    ).innerHTML = `<div class="msg ok">המבחן הוגש. תוצאה: ${correct} מתוך ${boxes.length} נכונות.</div>`;
  });
}

// ---------- Raffle (reads from the general notices system) ----------
const RAFFLE_CATEGORY = "זוכי הגרלה";

function renderRaffle() {
  const notices = DB.get(KEYS.notices, []).filter((n) => n.category === RAFFLE_CATEGORY);
  const body = document.getElementById("raffle-body");
  if (!notices.length) {
    body.innerHTML = `<tr><td colspan="3" style="color:var(--ink-soft)">עדיין לא פורסמו זוכים. ניתן להוסיף בלוח הניהול, תחת "ניהול הודעות ורשימות", בקטגוריה "${RAFFLE_CATEGORY}".</td></tr>`;
    return;
  }
  body.innerHTML = notices
    .map((n) => `<tr><td>${n.date}</td><td>${n.title}</td><td>${n.body}</td></tr>`)
    .join("");
}

// ---------- Admin ----------
function renderAdminRegistrants() {
  const registrants = DB.get(KEYS.registrants, []);
  const body = document.getElementById("admin-reg-body");
  body.innerHTML = registrants
    .map(
      (r) => `<tr>
        <td>${r.first} ${r.last}</td><td>${r.id}</td><td>${r.city}</td>
        <td>${r.unitLabel || "טרם נבחרה"}</td>
        <td style="display:flex; gap:6px">
          <button class="btn secondary" data-edit="${r.id}" style="padding:4px 10px; font-size:.8rem">ערוך</button>
          <button class="btn secondary" data-del="${r.id}" style="padding:4px 10px; font-size:.8rem">מחק</button>
        </td>
      </tr>`
    )
    .join("");

  body.querySelectorAll("[data-edit]").forEach((b) =>
    b.addEventListener("click", () => openEditRegistrant(b.dataset.edit))
  );
  body.querySelectorAll("[data-del]").forEach((b) =>
    b.addEventListener("click", () => deleteRegistrant(b.dataset.del))
  );
}

function openEditRegistrant(id) {
  const registrants = DB.get(KEYS.registrants, []);
  const r = registrants.find((x) => x.id === id);
  if (!r) return;
  const area = document.getElementById("edit-reg-area");
  area.innerHTML = `
    <div class="card" style="border-color:var(--wine)">
      <h3>עריכת נרשם — ${r.first} ${r.last}</h3>
      <div class="field-row">
        <div class="field"><label>שם פרטי</label><input id="e-first" value="${r.first}" /></div>
        <div class="field"><label>שם משפחה</label><input id="e-last" value="${r.last}" /></div>
      </div>
      <div class="field-row">
        <div class="field"><label>טלפון</label><input id="e-phone" value="${r.phone || ""}" /></div>
        <div class="field"><label>עיר</label><input id="e-city" value="${r.city || ""}" /></div>
      </div>
      <button class="btn" id="e-save">שמור שינויים</button>
      <button class="btn secondary" id="e-cancel">ביטול</button>
    </div>
  `;
  document.getElementById("e-save").addEventListener("click", () => {
    r.first = document.getElementById("e-first").value;
    r.last = document.getElementById("e-last").value;
    r.phone = document.getElementById("e-phone").value;
    r.city = document.getElementById("e-city").value;
    DB.set(KEYS.registrants, registrants);
    area.innerHTML = "";
    renderAdminRegistrants();
  });
  document.getElementById("e-cancel").addEventListener("click", () => (area.innerHTML = ""));
}

function deleteRegistrant(id) {
  if (!confirm("למחוק את הנרשם? כל יחידה או נקודת התחלה שתפס ישוחררו.")) return;

  const registrants = DB.get(KEYS.registrants, []).filter((r) => r.id !== id);
  DB.set(KEYS.registrants, registrants);

  const unitsTaken = DB.get(KEYS.unitsTaken, {});
  Object.keys(unitsTaken).forEach((k) => {
    if (unitsTaken[k] === id) delete unitsTaken[k];
  });
  DB.set(KEYS.unitsTaken, unitsTaken);

  const contTaken = DB.get(KEYS.contTaken, {});
  Object.keys(contTaken).forEach((k) => {
    if (contTaken[k] === id) delete contTaken[k];
  });
  DB.set(KEYS.contTaken, contTaken);

  const contProgress = DB.get(KEYS.contProgress, {});
  delete contProgress[id];
  DB.set(KEYS.contProgress, contProgress);

  const confirmed = DB.get(KEYS.confirmed, {});
  delete confirmed[id];
  DB.set(KEYS.confirmed, confirmed);

  renderAdminRegistrants();
  renderUnitGrid();
  renderStatusSummary();
}

document.getElementById("export-registrants").addEventListener("click", () => {
  const registrants = DB.get(KEYS.registrants, []);
  if (!registrants.length) {
    alert("אין עדיין נרשמים לייצוא.");
    return;
  }
  const rows = registrants.map((r) => ({
    "שם פרטי": r.first,
    "שם משפחה": r.last,
    "ת.ז.": r.id,
    "טלפון": r.phone,
    "סטטוס": r.status,
    "עיר": r.city,
    "יחידה": r.unitLabel || "",
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "נרשמים");
  XLSX.writeFile(wb, "נרשמים-היכל-המשנה.xlsx");
});

// ---------- General notices system ----------
function renderNotices() {
  const notices = DB.get(KEYS.notices, []);
  const body = document.getElementById("notices-body");
  body.innerHTML = notices
    .map(
      (n) => `<tr>
        <td>${n.category}</td><td>${n.date}</td><td>${n.title}</td><td>${n.body}</td>
        <td><button class="btn secondary" data-ndel="${n.id}" style="padding:4px 10px; font-size:.8rem">מחק</button></td>
      </tr>`
    )
    .join("");
  body.querySelectorAll("[data-ndel]").forEach((b) =>
    b.addEventListener("click", () => {
      const all = DB.get(KEYS.notices, []).filter((n) => String(n.id) !== b.dataset.ndel);
      DB.set(KEYS.notices, all);
      renderNotices();
      renderRaffle();
    })
  );
}

document.getElementById("notice-save").addEventListener("click", () => {
  const category = document.getElementById("notice-category").value.trim();
  const date = document.getElementById("notice-date").value.trim();
  const title = document.getElementById("notice-title").value.trim();
  const body = document.getElementById("notice-body").value.trim();
  if (!category || !title) {
    alert("יש למלא לפחות קטגוריה וכותרת.");
    return;
  }
  const all = DB.get(KEYS.notices, []);
  all.push({ id: Date.now(), category, date, title, body });
  DB.set(KEYS.notices, all);
  ["notice-category", "notice-date", "notice-title", "notice-body"].forEach(
    (id) => (document.getElementById(id).value = "")
  );
  renderNotices();
  renderRaffle();
});

// ---------- Status summary ----------
function renderStatusSummary() {
  const units8 = computeUnits(8);
  const units4 = computeUnits(4);
  const taken = DB.get(KEYS.unitsTaken, {});
  const taken8 = units8.filter((u) => taken[u.id]).length;
  const taken4 = units4.filter((u) => taken[u.id]).length;
  const contTaken = Object.keys(DB.get(KEYS.contTaken, {})).length;
  const totalPoints = allStartingPoints().length;

  document.getElementById("status-summary").innerHTML = `
    <div class="card" style="margin:0"><h3 style="font-size:1rem">יחידות 8 פרקים</h3><p>${taken8} תפוסות מתוך ${units8.length}</p></div>
    <div class="card" style="margin:0"><h3 style="font-size:1rem">יחידות 4 פרקים</h3><p>${taken4} תפוסות מתוך ${units4.length}</p></div>
    <div class="card" style="margin:0"><h3 style="font-size:1rem">מסלול רציף</h3><p>${contTaken} נקודות תפוסות מתוך ${totalPoints}</p></div>
  `;
}

document.getElementById("ann-save").addEventListener("click", () => {
  const title = document.getElementById("ann-title").value.trim();
  const body = document.getElementById("ann-body").value.trim();
  if (!title && !body) return;
  DB.set(KEYS.announcement, { title, body });
  sessionStorage.removeItem(KEYS.dismissed);
  alert("ההודעה פורסמה ותוצג למבקרים.");
});

document.getElementById("reset-all").addEventListener("click", () => {
  if (!confirm("לאפס את כל נתוני ההדגמה?")) return;
  Object.values(KEYS).forEach((k) => localStorage.removeItem(k));
  location.reload();
});

// ---------- Announcement popup ----------
function maybeShowAnnouncement() {
  const ann = DB.get(KEYS.announcement, null);
  if (!ann || sessionStorage.getItem(KEYS.dismissed)) return;
  document.getElementById("popup-title").textContent = ann.title;
  document.getElementById("popup-body").textContent = ann.body;
  document.getElementById("announcement-overlay").classList.remove("hidden");
}
document.getElementById("popup-close").addEventListener("click", () => {
  sessionStorage.setItem(KEYS.dismissed, "1");
  document.getElementById("announcement-overlay").classList.add("hidden");
});

// ---------- Init ----------
renderUnitGrid();
renderRaffle();
renderAdminRegistrants();
renderNotices();
renderStatusSummary();
updateBankCount();
renderExamMasechetList();
loadTaharotConfigForm();
updateMishnayotMapCount();
maybeShowAnnouncement();
