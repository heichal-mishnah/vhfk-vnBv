// data.js — נתוני ששה סדרי משנה
// כל סדר: שם, וסדר המסכתות עם מספר הפרקים בכל מסכת

const SHAS = [
  {
    seder: "זרעים",
    masechtot: [
      { name: "ברכות", perakim: 9 },
      { name: "פאה", perakim: 8 },
      { name: "דמאי", perakim: 7 },
      { name: "כלאים", perakim: 9 },
      { name: "שביעית", perakim: 10 },
      { name: "תרומות", perakim: 11 },
      { name: "מעשרות", perakim: 5 },
      { name: "מעשר שני", perakim: 5 },
      { name: "חלה", perakim: 4 },
      { name: "ערלה", perakim: 3 },
      { name: "ביכורים", perakim: 3 },
    ],
  },
  {
    seder: "מועד",
    masechtot: [
      { name: "שבת", perakim: 24 },
      { name: "עירובין", perakim: 10 },
      { name: "פסחים", perakim: 10 },
      { name: "שקלים", perakim: 8 },
      { name: "יומא", perakim: 8 },
      { name: "סוכה", perakim: 5 },
      { name: "ביצה", perakim: 5 },
      { name: "ראש השנה", perakim: 4 },
      { name: "תענית", perakim: 4 },
      { name: "מגילה", perakim: 4 },
      { name: "מועד קטן", perakim: 3 },
      { name: "חגיגה", perakim: 3 },
    ],
  },
  {
    seder: "נשים",
    masechtot: [
      { name: "יבמות", perakim: 16 },
      { name: "כתובות", perakim: 13 },
      { name: "נדרים", perakim: 11 },
      { name: "נזיר", perakim: 9 },
      { name: "סוטה", perakim: 9 },
      { name: "גיטין", perakim: 9 },
      { name: "קידושין", perakim: 4 },
    ],
  },
  {
    seder: "נזיקין",
    masechtot: [
      { name: "בבא קמא", perakim: 10 },
      { name: "בבא מציעא", perakim: 10 },
      { name: "בבא בתרא", perakim: 10 },
      { name: "סנהדרין", perakim: 11 },
      { name: "מכות", perakim: 3 },
      { name: "שבועות", perakim: 8 },
      { name: "עדויות", perakim: 8 },
      { name: "עבודה זרה", perakim: 5 },
      { name: "אבות", perakim: 5 },
      { name: "הוריות", perakim: 3 },
    ],
  },
  {
    seder: "קדשים",
    masechtot: [
      { name: "זבחים", perakim: 14 },
      { name: "מנחות", perakim: 13 },
      { name: "חולין", perakim: 12 },
      { name: "בכורות", perakim: 9 },
      { name: "ערכין", perakim: 9 },
      { name: "תמורה", perakim: 7 },
      { name: "כריתות", perakim: 6 },
      { name: "מעילה", perakim: 6 },
      { name: "תמיד", perakim: 7 },
      { name: "מדות", perakim: 5 },
      { name: "קנים", perakim: 3 },
    ],
  },
  {
    seder: "טהרות",
    masechtot: [
      { name: "כלים", perakim: 30 },
      { name: "אהלות", perakim: 18 },
      { name: "נגעים", perakim: 14 },
      { name: "פרה", perakim: 12 },
      { name: "טהרות", perakim: 10 },
      { name: "מקואות", perakim: 10 },
      { name: "נדה", perakim: 10 },
      { name: "מכשירין", perakim: 6 },
      { name: "זבים", perakim: 5 },
      { name: "טבול יום", perakim: 4 },
      { name: "ידים", perakim: 4 },
      { name: "עוקצין", perakim: 3 },
    ],
  },
];

// שיוך של כל פרק ופרק למספר סידורי גלובלי בתוך הסדר שלו,
// כדי לאפשר חיתוך ליחידות רציפות בלי לחצות סדר.
function flattenSeder(seder) {
  const list = [];
  seder.masechtot.forEach((m) => {
    for (let p = 1; p <= m.perakim; p++) {
      list.push({ masechet: m.name, perek: p });
    }
  });
  return list;
}

window.SHAS = SHAS;
window.flattenSeder = flattenSeder;
