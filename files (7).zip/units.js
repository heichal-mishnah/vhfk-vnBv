// units.js — חלוקה אוטומטית של הש"ס ליחידות לימוד
// כלל: יחידה אף פעם לא חוצה סדר. חותכים כל סדר בנפרד למקטעים בגודל groupSize
// (8 או 4), כאשר המקטע האחרון בסדר יכול להיות קצר יותר.

function computeUnits(groupSize) {
  const units = [];
  SHAS.forEach((seder) => {
    const flat = flattenSeder(seder);
    for (let i = 0; i < flat.length; i += groupSize) {
      const chunk = flat.slice(i, i + groupSize);
      const start = chunk[0];
      const end = chunk[chunk.length - 1];
      const label =
        start.masechet === end.masechet
          ? `${start.masechet} פרק ${start.perek}${
              start.perek === end.perek ? "" : `–${end.perek}`
            }`
          : `${start.masechet} פרק ${start.perek} – ${end.masechet} פרק ${end.perek}`;
      units.push({
        id: `${seder.seder}-${groupSize}-${units.length}`,
        seder: seder.seder,
        groupSize,
        perakim: chunk,
        label,
      });
    }
  });
  return units;
}

// כל נקודת פרק אפשרית בש"ס, לשימוש במסלול הרציף (בחירת נקודת התחלה)
function allStartingPoints() {
  const points = [];
  SHAS.forEach((seder) => {
    flattenSeder(seder).forEach((p) => {
      points.push({ seder: seder.seder, masechet: p.masechet, perek: p.perek });
    });
  });
  return points;
}

// מהפרק הנוכחי, מחזיר את הפרק הבא ברצף (עובר בין מסכתות אך לא בין סדרים
// — כשמגיעים לסוף הסדר חוזרים להתחלתו, כדי שהמסלול הרציף לא ייתקע)
function nextPerek(seder, masechet, perek) {
  const s = SHAS.find((s) => s.seder === seder);
  const flat = flattenSeder(s);
  const idx = flat.findIndex((p) => p.masechet === masechet && p.perek === perek);
  const next = flat[(idx + 1) % flat.length];
  return { seder, masechet: next.masechet, perek: next.perek };
}

window.computeUnits = computeUnits;
window.allStartingPoints = allStartingPoints;
window.nextPerek = nextPerek;
